    #include <p33FJ64MC802.h>
	#include <libpic30.h>
    #include <stdio.h>
    #include <stdlib.h>
    #include <string.h>
	
   
	#define FCY             39613000        //Instruction Cycle Frequency
	#define BAUDRATE         9600		      
	#define BRGVAL          ((FCY/BAUDRATE)/16)-1
	#define BAUDRATE2         19200	      
	#define BRGVAL2          ((FCY/BAUDRATE2)/16)-1  

    
	void clk(void);
    void configuration();
    unsigned char GET_C1(void);
    void UART_BINOCULAR();
    unsigned char GET_C2(void);
    void TRANSMIT_C1(unsigned char value);
    
    char arr,data[100],read;
    unsigned int j=0;
    
   
   

    void __attribute__((__interrupt__, no_auto_psv)) _U1RXInterrupt(void)
    {

   
	arr = GET_C1();

    }

  void __attribute__((__interrupt__, no_auto_psv)) _U2RXInterrupt(void)
{

   
	read = GET_C2();
	
  

}


    int main(void)
     {

       clk();
       
       configuration();
  
       while(1);
        {
        TRANSMIT_C1('a');  
        }             
      return(0);
     }





     ///////////////////////////////////////////////////////////////////// CLOCK ///////////////////////////////////////////////////////////////////
	void clk(void)
	{
	
    	 // Configure Oscillator to operate the device at 40Mhz
	    // Fosc= Fin*M/(N1*N2), Fcy=Fosc/2
	   // Fosc= 7.37*43/(2*2)=79.23MHz
		PLLFBD=41;					// M=43
		CLKDIVbits.PLLPOST=0;		// N1=2
		CLKDIVbits.PLLPRE=0;		// N2=2
	

		RCONbits.SWDTEN=0;	               //////////////////////// Disable Watch Dog Timer //////////////////////////////////
	
	
		while(OSCCONbits.LOCK!=1) {};    /////////////////////////// Wait for PLL to lock  //////////////////////////////////
	}


    /////////////////////////////////////////////////////////////// CONFIGURATION //////////////////////////////////////////////////////////////

	 void configuration()
	{

	   __delay32(20000000);

	   UART_BINOCULAR();
	   //UART_CAMPUS();
	}


    ///////////////////////////////////////////////////////////// INITIALIZING UART 1 ////////////////////////////////////////////////////////
   	void UART_CAMPUS()                     
    {	
	RPINR18 = 4;	                      ///////////////////////////////// Receive ///////////////////////////////// 	
	RPOR2bits.RP5R = 3;	                  ///////////////////////////////// Transmit ///////////////////////////////// 
		
	TRISBbits.TRISB4 = 1;                 ///////////////////////////////// Receive ///////////////////////////////// 
	TRISBbits.TRISB5=  0;                 ///////////////////////////////// Transmit /////////////////////////////////
	
	U1BRG  = BRGVAL;

	_U1RXIP = 7;	
	_U1RXIF = 0;
    _U1RXIE = 1;

	U1MODE = 0x8000; 	
	U1STA  = 0x0440; 
    }

   ///////////////////////////////////////////////////////// TRANSMIT FUNCTION FOR UART 1 //////////////////////////////////////////

    void TRANSMIT_C1(unsigned char value)
    {
	while(!U1STAbits.TRMT);
	U1TXREG = value;
	while(!U1STAbits.TRMT);
	_U1RXIF=0;			 	         /////////////////////////Clear UART RX Interrupt Flag /////////////////////////////////////
    }


    ///////////////////////////////////////////////////// RECEIVE FUNCTION FOR UART 1 ///////////////////////////////////////////////////

    unsigned char GET_C1(void)
    {
	while (_U1RXIF==0);			         /////////////////////////// Wait and Receive One Character ///////////////////////////////
	_U1RXIF = 0;
    data[j]=U1RXREG;
    j++;
    _U1RXIF==0;
	return U1RXREG;
    }

 	void UART_BINOCULAR()           ///////////////////// serial 1 controller 2 //////////////////////
{	
	RPINR19 = 12;	// = 9 acceptable		
	RPOR5bits.RP11R = 5;	
		
	TRISBbits.TRISB12 = 1; //7
	TRISBbits.TRISB11=  0; //6
	
	U2BRG  = BRGVAL;

	_U2RXIP = 7;	
	_U2RXIF = 0;
    _U2RXIE = 1;

	U2MODE = 0x8000; 	
	U2STA  = 0x0440; 
		
}

////////////////////////////////////////////////////// TRANSMIT FUNCTION FOR UART 2 /////////////////////////////////////////////////

void TRANSMIT_C2(unsigned char value)
{
	while(!U2STAbits.TRMT);
	U2TXREG = value;
	while(!U2STAbits.TRMT);
	_U2RXIF=0;				//Clear UART RX Interrupt Flag
}

//////////////////////////////////////////////////// RECEIVE FUNCTION FOR UART 2 /////////////////////////////////////////////////////////

unsigned char GET_C2(void)
{
	while (IFS1bits.U2RXIF==0);			// Wait and Receive One Character
	IFS1bits.U2RXIF = 0;
    data[j]=U2RXREG;
    j++;
	return U2RXREG;
}


