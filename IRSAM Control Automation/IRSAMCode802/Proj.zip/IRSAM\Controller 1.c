    #include <p33FJ64MC802.h>
	#include <libpic30.h>
    #include <stdio.h>
    #include <stdlib.h>
    #include <string.h>
	
   
	#define FCY             39613000        //Instruction Cycle Frequency
	#define BAUDRATE         9600		      
	#define BRGVAL          ((FCY/BAUDRATE)/16)-1
	#define BAUDRATE2         19200	      
	#define BRGVAL2          ((FCY/BAUDRATE2)/16)-1  

    
	void clk(void);
    void configuration();

   ///////////////////////////////////////////////////////////// Serial Functions ///////////////////////////////////////////////////////////
    
    void UART_BINOCULER();
    void UART_LCD();
    unsigned char GET_C1(void);
    unsigned char GET_C2(void); 
    void TRANSMIT_C1(unsigned char value);
    void TRANSMIT_C2(unsigned char value);

    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    /////////////////////////////////////////////////////////// LCD Functions /////////////////////////////////////////////////////////////

    void setting_lcd();
    void display_window();
    void display_window2();
    void print_care();
    void button4();   
    void text_button4(); 
    void enable_touch();
    void detect_region();

    char arr,data[100];
    unsigned int j=0,a=0;
    unsigned int read=0,read1=0,readx=0,ready=0,readx1=0,ready1=0;
    
   
   

    void __attribute__((__interrupt__, no_auto_psv)) _U1RXInterrupt(void)
    {

   
	arr = GET_C1();

    }

   void __attribute__((__interrupt__, no_auto_psv)) _U2RXInterrupt(void)
   {

   
	read = GET_C2();
	
  }


    int main(void)
     {
        unsigned int i=0;
        char str[10];  
        clk();
       
        configuration();


        
        setting_lcd();
        display_window();
        display_window2();
        print_care();
        button4(); 
        text_button4();
        enable_touch();
       
        while(1)
        {
             read=0;
             detect_region();
        }
         
        return(0);
     }





     ///////////////////////////////////////////////////////////////////// CLOCK ///////////////////////////////////////////////////////////////////
	void clk(void)
	{
	
    	 // Configure Oscillator to operate the device at 40Mhz
	    // Fosc= Fin*M/(N1*N2), Fcy=Fosc/2
	   // Fosc= 7.37*43/(2*2)=79.23MHz
		PLLFBD=41;					// M=43
		CLKDIVbits.PLLPOST=0;		// N1=2
		CLKDIVbits.PLLPRE=0;		// N2=2
	

		RCONbits.SWDTEN=0;	               //////////////////////// Disable Watch Dog Timer //////////////////////////////////
	
	
		while(OSCCONbits.LOCK!=1) {};    /////////////////////////// Wait for PLL to lock  //////////////////////////////////
	}


    /////////////////////////////////////////////////////////////// CONFIGURATION //////////////////////////////////////////////////////////////

	 void configuration()
	{

	   
	__delay32(40000000); //2 SEC delay
	__delay32(20000000); //2 SEC delay

	  UART_BINOCULER();
      UART_LCD();
	
	}


    ///////////////////////////////////////////////////////////// INITIALIZING UART 1 ////////////////////////////////////////////////////////
   	void UART_BINOCULER()                     
    {	
	RPINR18 = 4;	                      ///////////////////////////////// Receive ///////////////////////////////// 	
	RPOR2bits.RP5R = 3;	                  ///////////////////////////////// Transmit ///////////////////////////////// 
		
	TRISBbits.TRISB4 = 1;                 ///////////////////////////////// Receive ///////////////////////////////// 
	TRISBbits.TRISB5=  0;                 ///////////////////////////////// Transmit /////////////////////////////////
	
	U1BRG  = BRGVAL;

	_U1RXIP = 7;	
	_U1RXIF = 0;
    _U1RXIE = 1;

	U1MODE = 0x8000; 	
	U1STA  = 0x0440; 
    }

    ///////////////////////////////////////////////////////////// INITIALIZING UART 2 ////////////////////////////////////////////////////////
   	void UART_LCD()                     
    {	
	RPINR19 = 14;	                      ///////////////////////////////// Receive ///////////////////////////////// 	
	RPOR7bits.RP15R = 5;	                  ///////////////////////////////// Transmit ///////////////////////////////// 
		
	TRISBbits.TRISB14 = 1;                 ///////////////////////////////// Receive ///////////////////////////////// 
	TRISBbits.TRISB15=  0;                 ///////////////////////////////// Transmit /////////////////////////////////
	
	U2BRG  = BRGVAL;

	IPC7bits.U2RXIP = 7;	
	IFS1bits.U2RXIF = 0;
	IEC1bits.U2RXIE = 1;

	U2MODE = 0x8000; 	
	U2STA  = 0x0440; 
    }
 

   ///////////////////////////////////////////////////////// TRANSMIT FUNCTION FOR UART 1 //////////////////////////////////////////

    void TRANSMIT_C1(unsigned char value)
    {
	while(!U1STAbits.TRMT);
	U1TXREG = value;
	while(!U1STAbits.TRMT);
	_U1RXIF=0;			 	         /////////////////////////Clear UART RX Interrupt Flag /////////////////////////////////////
    }


    ///////////////////////////////////////////////////// RECEIVE FUNCTION FOR UART 1 ///////////////////////////////////////////////////

    unsigned char GET_C1(void)
    {
	while (_U1RXIF==0);			         /////////////////////////// Wait and Receive One Character ///////////////////////////////
	_U1RXIF = 0;
    j++;
    data[j]=U1RXREG;
   
    _U1RXIF==0;
	return U1RXREG;
    }

   //////////////////////////////////////////////////// RECEIVE FUNCTION FOR UART 2 /////////////////////////////////////////////////////////

	unsigned char GET_C2(void)
	{
		while (IFS1bits.U2RXIF==0);			// Wait and Receive One Character
		IFS1bits.U2RXIF = 0;
		return U2RXREG;
	}

   ////////////////////////////////////////////////////// TRANSMIT FUNCTION FOR UART 2 /////////////////////////////////////////////////

   void TRANSMIT_C2(unsigned char value)
   {
	while(!U2STAbits.TRMT);
	U2TXREG = value;
	while(!U2STAbits.TRMT);
	_U2RXIF=0;				//Clear UART RX Interrupt Flag
   }

   //////////////////////////////////////////////////////////// Setting The LCD /////////////////////////////////////////////////////////

   void setting_lcd()
   {
        TRANSMIT_C2('U');      /////////////////////////// Auto Baud Rate ///////////////////////////////////
           
        __delay32(500000);

		a=0x59;               //////////////////////// Making Display Horizontal //////////////////////////////
		TRANSMIT_C2(a);
		a=0x04;
		TRANSMIT_C2(a);
		a=0x01;
		TRANSMIT_C2(a);

        __delay32(800000);
  

   } 

    /////////////////////////////////////////////////////////////// DISPLAY WINDOW OF LCD //////////////////////////////////////////

	void display_window()
	{
	
	a=0x72;              ////////////////////////// DISPLAY WINDOW ////////////////////////////////////
	TRANSMIT_C2(a);
	
	a=0x00;             ///////////////////////// HORIZONTAL START //////////////////////////////////
	TRANSMIT_C2(a);
	a=0x10;
	TRANSMIT_C2(a);
	a=0x00;             ///////////////////////// VERTICAL START //////////////////////////////////
	TRANSMIT_C2(a);
	a=0x06;
	TRANSMIT_C2(a);
	
	a=0x00;            ///////////////////////// HORIZONTAL END //////////////////////////////////
	TRANSMIT_C2(a);
	a=0x71;
	TRANSMIT_C2(a);
	a=0x00;            ///////////////////////// VERTICAL END //////////////////////////////////
	TRANSMIT_C2(a);
	a=0xB0;
	TRANSMIT_C2(a);
	
	
	a=0xff;         ///////////// color
	TRANSMIT_C2(a);
	a=0xff;
	TRANSMIT_C2(a);

    __delay32(5000000);
	
	
	}


    /////////////////////////////////////////////////////////////// DISPLAY WINDOW 2 OF LCD //////////////////////////////////////////

	void display_window2()
	{
	
	a=0x72;              ////////////////////////// DISPLAY WINDOW ////////////////////////////////////
	TRANSMIT_C2(a);
	
	a=0x00;             ///////////////////////// HORIZONTAL START //////////////////////////////////
	TRANSMIT_C2(a);
	a=0x80;
	TRANSMIT_C2(a);
	a=0x00;             ///////////////////////// VERTICAL START //////////////////////////////////
	TRANSMIT_C2(a);
	a=0x06;
	TRANSMIT_C2(a);
	
	a=0x00;            ///////////////////////// HORIZONTAL END //////////////////////////////////
	TRANSMIT_C2(a);
	a=0xE4;
	TRANSMIT_C2(a);
	a=0x00;            ///////////////////////// VERTICAL END //////////////////////////////////
	TRANSMIT_C2(a);
	a=0xB0;
	TRANSMIT_C2(a);
	a=0xff;         ///////////// color
	TRANSMIT_C2(a);
	a=0xff;
	TRANSMIT_C2(a);

    __delay32(5000000);
	
	
	}

    //////////////////////////////////////////////////////////////////////// Print CARE //////////////////////////////////////////////////////

    void print_care()
    {

        a=0x74;              
    	TRANSMIT_C2(a);
        a=0x43;              
    	TRANSMIT_C2(a);
        a=0x01;             ///////////////////////// HORIZONTAL START //////////////////////////////////
		TRANSMIT_C2(a);
		a=0x00;
		TRANSMIT_C2(a);
		a=0x00;             ///////////////////////// VERTICAL START //////////////////////////////////
		TRANSMIT_C2(a);
		a=0x10;
		TRANSMIT_C2(a);
		a=0xFF;              
    	TRANSMIT_C2(a);
        a=0xFF;              
    	TRANSMIT_C2(a);
        a=0x05;              
    	TRANSMIT_C2(a);
	    a=0x05;              
    	TRANSMIT_C2(a);

	    __delay32(5000000);

	    a=0x74;              
    	TRANSMIT_C2(a);
        a=0x41;              
    	TRANSMIT_C2(a);
        a=0x01;             ///////////////////////// HORIZONTAL START //////////////////////////////////
		TRANSMIT_C2(a);
		a=0x00;
		TRANSMIT_C2(a);
		a=0x00;             ///////////////////////// VERTICAL START //////////////////////////////////
		TRANSMIT_C2(a);
		a=0x40;
		TRANSMIT_C2(a);
		a=0xFF;              
    	TRANSMIT_C2(a);
        a=0xFF;              
    	TRANSMIT_C2(a);
        a=0x05;              
    	TRANSMIT_C2(a);
	    a=0x05;              
    	TRANSMIT_C2(a);
	    
		__delay32(5000000);

	    a=0x74;              
    	TRANSMIT_C2(a);
        a=0x52;              
    	TRANSMIT_C2(a);
        a=0x01;             ///////////////////////// HORIZONTAL START //////////////////////////////////
		TRANSMIT_C2(a);
		a=0x00;
		TRANSMIT_C2(a);
		a=0x00;             ///////////////////////// VERTICAL START //////////////////////////////////
		TRANSMIT_C2(a);
		a=0x70;
		TRANSMIT_C2(a);
		a=0xFF;              
    	TRANSMIT_C2(a);
        a=0xFF;              
    	TRANSMIT_C2(a);
        a=0x05;              
    	TRANSMIT_C2(a);
	    a=0x05;              
    	TRANSMIT_C2(a);
	    
	    __delay32(5000000);

	    a=0x74;              
    	TRANSMIT_C2(a);
        a=0x45;              
    	TRANSMIT_C2(a);
        a=0x01;             ///////////////////////// HORIZONTAL START //////////////////////////////////
		TRANSMIT_C2(a);
		a=0x00;
		TRANSMIT_C2(a);
		a=0x00;             ///////////////////////// VERTICAL START //////////////////////////////////
		TRANSMIT_C2(a);
		a=0xA0;
		TRANSMIT_C2(a);
		a=0xFF;              
    	TRANSMIT_C2(a);
        a=0xFF;              
    	TRANSMIT_C2(a);
        a=0x05;              
    	TRANSMIT_C2(a);
	    a=0x05;              
    	TRANSMIT_C2(a);
        
		__delay32(5000000);
	}

//////////////////////////////////////////////////////////////// BUTTON FOR BACK ////////////////////////////////////////////////////////////////

void button4()
{

a=0x72;              ////////////////////////// DISPLAY WINDOW ////////////////////////////////////
TRANSMIT_C2(a);

a=0x00;             ///////////////////////// HORIZONTAL START //////////////////////////////////
TRANSMIT_C2(a);
a=0x38;
TRANSMIT_C2(a);
a=0x00;             ///////////////////////// VERTICAL START //////////////////////////////////
TRANSMIT_C2(a);
a=0xB4;
TRANSMIT_C2(a);

a=0x00;            ///////////////////////// HORIZONTAL END //////////////////////////////////
TRANSMIT_C2(a);
a=0xB4;
TRANSMIT_C2(a);
a=0x00;            ///////////////////////// VERTICAL END //////////////////////////////////
TRANSMIT_C2(a);
a=0xEC;
TRANSMIT_C2(a);


a=0x00;            ////////////////////////////   COLOR   ///////////////////////////////////////
TRANSMIT_C2(a);
a=0x1F;
TRANSMIT_C2(a);

__delay32(10000000);
}


////////////////////////////////////////////////////////////// ENABLING TOUCH SCREEN /////////////////////////////////////////////////////

void enable_touch()
{

a=0x59; 
TRANSMIT_C2(a);
a=0x05;
TRANSMIT_C2(a);
a=0x00;
TRANSMIT_C2(a);
__delay32(10000000);
read=0;
__delay32(7000000);
}


////////////////////////////////////////////////////////////// FUNCTION TO DETECT TOUCH REGION ///////////////////////////////////////////////////

void detect_region()
{

a=0x6F;
TRANSMIT_C2(a);
a=0x00;
TRANSMIT_C2(a);
while(read==0);

readx=read;

while(read==readx);

readx1=read;

while(read==readx1);

ready=read;

if(readx>56 && readx<180)
{


    
        if(ready>180 && ready<236)          ///////////////////////////////////// BUTTON 1 H / P / R ////////////////////////////////////////////////
			{ 
             __delay32(8000000);
             
	            func_button1();
                //while(1);
            }  
}       
}


/////////////////////////////////////////////////////////// buttion Text //////////////////////////////////////////////////////////

void text_button4()
{
a=0x73;                //////////////////////////////// COMMAND ///////////////////////////////
TRANSMIT_C2(a); 
a=0x0D;                ///////////////////////////// HORZONTAL START //////////////////////////
TRANSMIT_C2(a);
a=0x11;                ///////////////////////////// VERTICAL START ///////////////////////////
TRANSMIT_C2(a);
a=0x02;                ///////////////////////////// TEXT SIZE ////////////////////////////////
TRANSMIT_C2(a);
a=0xFF;                //////////////////////////// COLOUR /////////////////////////////////////
TRANSMIT_C2(a);
a=0xFF;
TRANSMIT_C2(a);

TRANSMIT_C2('S');
TRANSMIT_C2('T');
TRANSMIT_C2('A');
TRANSMIT_C2('R');
TRANSMIT_C2('T');


a=0x00;
TRANSMIT_C2(a);   /////////////////////////////// END TEXT /////////////////////////////////////
   __delay32(8000000);
}

void text_button2()
{
a=0x73;                //////////////////////////////// COMMAND ///////////////////////////////
TRANSMIT_C2(a); 
a=0x0D;                ///////////////////////////// HORZONTAL START //////////////////////////
TRANSMIT_C2(a);
a=0x11;                ///////////////////////////// VERTICAL START ///////////////////////////
TRANSMIT_C2(a);
a=0x02;                ///////////////////////////// TEXT SIZE ////////////////////////////////
TRANSMIT_C2(a);
a=0xFF;                //////////////////////////// COLOUR /////////////////////////////////////
TRANSMIT_C2(a);
a=0xFF;
TRANSMIT_C2(a);

TRANSMIT_C2('S');
TRANSMIT_C2('T');
TRANSMIT_C2('O');
TRANSMIT_C2('P');



a=0x00;
TRANSMIT_C2(a);   /////////////////////////////// END TEXT /////////////////////////////////////
   __delay32(8000000);
}


void func_button1()
{

 unsigned int i=0,s=0;

char str[30];          //////////////////////// DECLARING ARRAY ///////////////////////////////

__delay32(5000000);

text_button2();

__delay32(5000000);

a=0x73;                //////////////////////// DISPLAY HEADING ///////////////////////////////////////
TRANSMIT_C2(a); 
a=0x02;                //////////////////////// HORZONTAL START //////////////////////////////////////
TRANSMIT_C2(a);
a=0x01;                /////////////////////// VERTICAL START ///////////////////////////////////////
TRANSMIT_C2(a);
a=0x03;
TRANSMIT_C2(a);
a=0x00;
TRANSMIT_C2(a);
a=0x00;
TRANSMIT_C2(a);

TRANSMIT_C2('H');      /////////////////////// PRINTING //////////////////////////////////////////
TRANSMIT_C2('E');
TRANSMIT_C2('A');
TRANSMIT_C2('D');
TRANSMIT_C2('I');
TRANSMIT_C2('N');
TRANSMIT_C2('G');

a=0x00;              ///////////////////////// END OF STRING /////////////////////////////////////
TRANSMIT_C2(a);

__delay32(3500000);

a=0x73;                //////////////////////// DISPLAY HEADING ///////////////////////////////////////
TRANSMIT_C2(a); 
a=0x0B;                //////////////////////// HORZONTAL START //////////////////////////////////////
TRANSMIT_C2(a);
a=0x01;                /////////////////////// VERTICAL START ///////////////////////////////////////
TRANSMIT_C2(a);
a=0x03;
TRANSMIT_C2(a);
a=0x00;
TRANSMIT_C2(a);
a=0x00;
TRANSMIT_C2(a);

TRANSMIT_C2('P');      /////////////////////// PRINTING //////////////////////////////////////////
TRANSMIT_C2('I');
TRANSMIT_C2('T');
TRANSMIT_C2('C');
TRANSMIT_C2('H');


a=0x00;              ///////////////////////// END OF STRING /////////////////////////////////////
TRANSMIT_C2(a);

__delay32(350000);


  while(1)
               {     
                        if(data[j]=='H')
                             break;
                             j=0;
                         
               }

     while(1)
               {     
                        
                             
                         if(data[j]=='S')
                               break;
               }


             for(i=1;i<=12;i++)
			   {
				str[i]=data[i];
               } 
           


while(1)               ///////////////////////////////////// LOOP START //////////////////////////////////////////
{

j=0;

//__delay32(350000);      

a=0x73;             ///////////////////////////////////// PRINT HEADING /////////////////////////////////////////
TRANSMIT_C2(a);
a=0x02;
TRANSMIT_C2(a);
a=0x03;
TRANSMIT_C2(a);
a=0x03;
TRANSMIT_C2(a);
a=0x00;
TRANSMIT_C2(a);
TRANSMIT_C2(a);

for(s=2;s<=6;s++)
{
TRANSMIT_C2(str[s]);
}

a=0x00;
TRANSMIT_C2(a);      ////////////////////////////// END OF STRING //////////////////////////////////

__delay32(850000);      

a=0x73;             ///////////////////////////////////// PRINT HEADING /////////////////////////////////////////
TRANSMIT_C2(a);
a=0x0B;
TRANSMIT_C2(a);
a=0x03;
TRANSMIT_C2(a);
a=0x03;
TRANSMIT_C2(a);
a=0x00;
TRANSMIT_C2(a);
TRANSMIT_C2(a);

for(s=8;s<=12;s++)
{
TRANSMIT_C2(str[s]);
}

a=0x00;
TRANSMIT_C2(a);      ////////////////////////////// END OF STRING //////////////////////////////////

j=0;

__delay32(350000);
  while(1)
               {     
                        if(data[j]=='H')
                             break;
                             j=0;
                         
               }

     while(1)
               {     
                        
                             
                         if(data[j]=='S')
                               break;
               }


             for(i=1;i<=12;i++)
			   {
				str[i]=data[i];
               } 

//__delay32(350000);      
a=0x73;             ///////////////////////////////////// PRINT HEADING /////////////////////////////////////////
TRANSMIT_C2(a);
a=0x02;
TRANSMIT_C2(a);
a=0x04;
TRANSMIT_C2(a);
a=0x03;
TRANSMIT_C2(a);
a=0x00;
TRANSMIT_C2(a);
TRANSMIT_C2(a);

for(s=2;s<=6;s++)
{
TRANSMIT_C2(str[s]);
}

a=0x00;
TRANSMIT_C2(a);      ////////////////////////////// END OF STRING //////////////////////////////////
__delay32(350000);      

a=0x73;             ///////////////////////////////////// PRINT HEADING /////////////////////////////////////////
TRANSMIT_C2(a);
a=0x0B;
TRANSMIT_C2(a);
a=0x04;
TRANSMIT_C2(a);
a=0x03;
TRANSMIT_C2(a);
a=0x00;
TRANSMIT_C2(a);
TRANSMIT_C2(a);

for(s=8;s<=12;s++)
{
TRANSMIT_C2(str[s]);
}

a=0x00;
TRANSMIT_C2(a);      ////////////////////////////// END OF STRING //////////////////////////////////


j=0;

//__delay32(350000);
  while(1)
               {     
                        if(data[j]=='H')
                             break;
                             j=0;
                         
               }

     while(1)
               {     
                        
                             
                         if(data[j]=='S')
                               break;
               }


             for(i=1;i<=12;i++)
			   {
				str[i]=data[i];
               } 

//__delay32(350000);      
a=0x73;             ///////////////////////////////////// PRINT HEADING /////////////////////////////////////////
TRANSMIT_C2(a);
a=0x02;
TRANSMIT_C2(a);
a=0x05;
TRANSMIT_C2(a);
a=0x03;
TRANSMIT_C2(a);
a=0x00;
TRANSMIT_C2(a);
TRANSMIT_C2(a);

for(s=2;s<=6;s++)
{
TRANSMIT_C2(str[s]);
}

a=0x00;
TRANSMIT_C2(a);      ////////////////////////////// END OF STRING //////////////////////////////////
__delay32(350000);      

a=0x73;             ///////////////////////////////////// PRINT HEADING /////////////////////////////////////////
TRANSMIT_C2(a);
a=0x0B;
TRANSMIT_C2(a);
a=0x05;
TRANSMIT_C2(a);
a=0x03;
TRANSMIT_C2(a);
a=0x00;
TRANSMIT_C2(a);
TRANSMIT_C2(a);

for(s=8;s<=12;s++)
{
TRANSMIT_C2(str[s]);
}

a=0x00;
TRANSMIT_C2(a);      ////////////////////////////// END OF STRING //////////////////////////////////

j=0;

//__delay32(350000);
  while(1)
               {     
                        if(data[j]=='H')
                             break;
                             j=0;
                         
               }

     while(1)
               {     
                        
                             
                         if(data[j]=='S')
                               break;
               }


             for(i=1;i<=12;i++)
			   {
				str[i]=data[i];
               } 

//__delay32(350000);      
a=0x73;             ///////////////////////////////////// PRINT HEADING /////////////////////////////////////////
TRANSMIT_C2(a);
a=0x02;
TRANSMIT_C2(a);
a=0x06;
TRANSMIT_C2(a);
a=0x03;
TRANSMIT_C2(a);
a=0x00;
TRANSMIT_C2(a);
TRANSMIT_C2(a);

for(s=2;s<=6;s++)
{
TRANSMIT_C2(str[s]);
}

a=0x00;
TRANSMIT_C2(a);      ////////////////////////////// END OF STRING //////////////////////////////////

__delay32(350000);      

a=0x73;             ///////////////////////////////////// PRINT HEADING /////////////////////////////////////////
TRANSMIT_C2(a);
a=0x0B;
TRANSMIT_C2(a);
a=0x06;
TRANSMIT_C2(a);
a=0x03;
TRANSMIT_C2(a);
a=0x00;
TRANSMIT_C2(a);
TRANSMIT_C2(a);

for(s=8;s<=12;s++)
{
TRANSMIT_C2(str[s]);
}

a=0x00;
TRANSMIT_C2(a);      ////////////////////////////// END OF STRING //////////////////////////////////


j=0;

//__delay32(350000);
  while(1)
               {     
                        if(data[j]=='H')
                             break;
                             j=0;
                         
               }

     while(1)
               {     
                        
                             
                         if(data[j]=='S')
                               break;
               }


             for(i=1;i<=12;i++)
			   {
				str[i]=data[i];
               } 

//__delay32(350000);      
a=0x73;             ///////////////////////////////////// PRINT HEADING /////////////////////////////////////////
TRANSMIT_C2(a);
a=0x02;
TRANSMIT_C2(a);
a=0x07;
TRANSMIT_C2(a);
a=0x03;
TRANSMIT_C2(a);
a=0x00;
TRANSMIT_C2(a);
TRANSMIT_C2(a);

for(s=2;s<=6;s++)
{
TRANSMIT_C2(str[s]);
}

a=0x00;
TRANSMIT_C2(a);      ////////////////////////////// END OF STRING //////////////////////////////////

__delay32(350000);      

a=0x73;             ///////////////////////////////////// PRINT HEADING /////////////////////////////////////////
TRANSMIT_C2(a);
a=0x0B;
TRANSMIT_C2(a);
a=0x07;
TRANSMIT_C2(a);
a=0x03;
TRANSMIT_C2(a);
a=0x00;
TRANSMIT_C2(a);
TRANSMIT_C2(a);

for(s=8;s<=12;s++)
{
TRANSMIT_C2(str[s]);
}

a=0x00;
TRANSMIT_C2(a);      ////////////////////////////// END OF STRING //////////////////////////////////


j=0;

//__delay32(350000);
  while(1)
               {     
                        if(data[j]=='H')
                             break;
                             j=0;
                         
               }

     while(1)
               {     
                        
                             
                         if(data[j]=='S')
                               break;
               }


             for(i=1;i<=12;i++)
			   {
				str[i]=data[i];
               } 

//__delay32(350000);      
a=0x73;             ///////////////////////////////////// PRINT HEADING /////////////////////////////////////////
TRANSMIT_C2(a);
a=0x02;
TRANSMIT_C2(a);
a=0x08;
TRANSMIT_C2(a);
a=0x03;
TRANSMIT_C2(a);
a=0x00;
TRANSMIT_C2(a);
TRANSMIT_C2(a);

for(s=2;s<=6;s++)
{
TRANSMIT_C2(str[s]);
}

a=0x00;
TRANSMIT_C2(a);      ////////////////////////////// END OF STRING //////////////////////////////////
__delay32(350000);      

a=0x73;             ///////////////////////////////////// PRINT HEADING /////////////////////////////////////////
TRANSMIT_C2(a);
a=0x0B;
TRANSMIT_C2(a);
a=0x08;
TRANSMIT_C2(a);
a=0x03;
TRANSMIT_C2(a);
a=0x00;
TRANSMIT_C2(a);
TRANSMIT_C2(a);

for(s=8;s<=12;s++)
{
TRANSMIT_C2(str[s]);
}

a=0x00;
TRANSMIT_C2(a);      ////////////////////////////// END OF STRING //////////////////////////////////

j=0;

//__delay32(350000);
  while(1)
               {     
                        if(data[j]=='H')
                             break;
                             j=0;
                         
               }

     while(1)
               {     
                        
                             
                         if(data[j]=='S')
                               break;
               }


             for(i=1;i<=12;i++)
			   {
				str[i]=data[i];
               } 

//__delay32(350000);      
a=0x73;             ///////////////////////////////////// PRINT HEADING /////////////////////////////////////////
TRANSMIT_C2(a);
a=0x02;
TRANSMIT_C2(a);
a=0x09;
TRANSMIT_C2(a);
a=0x03;
TRANSMIT_C2(a);
a=0x00;
TRANSMIT_C2(a);
TRANSMIT_C2(a);

for(s=2;s<=6;s++)
{
TRANSMIT_C2(str[s]);
}

a=0x00;
TRANSMIT_C2(a);      ////////////////////////////// END OF STRING //////////////////////////////////

__delay32(350000);      

a=0x73;             ///////////////////////////////////// PRINT HEADING /////////////////////////////////////////
TRANSMIT_C2(a);
a=0x0B;
TRANSMIT_C2(a);
a=0x09;
TRANSMIT_C2(a);
a=0x03;
TRANSMIT_C2(a);
a=0x00;
TRANSMIT_C2(a);
TRANSMIT_C2(a);

for(s=8;s<=12;s++)
{
TRANSMIT_C2(str[s]);
}

a=0x00;
TRANSMIT_C2(a);      ////////////////////////////// END OF STRING //////////////////////////////////
__delay32(1050000); 
//display_black1();
display_black2();

while(1);


}

}

void display_black1()

{

a=0x72;              ////////////////////////// DISPLAY WINDOW ////////////////////////////////////
TRANSMIT_C2(a);

a=0x00;             ///////////////////////// HORIZONTAL START //////////////////////////////////
TRANSMIT_C2(a);
a=0x18;
TRANSMIT_C2(a);
a=0x00;             ///////////////////////// VERTICAL START //////////////////////////////////
TRANSMIT_C2(a);
a=0x30;
TRANSMIT_C2(a);

a=0x00;            ///////////////////////// HORIZONTAL END //////////////////////////////////
TRANSMIT_C2(a);
a=0x54;
TRANSMIT_C2(a);
a=0x00;            ///////////////////////// VERTICAL END //////////////////////////////////
TRANSMIT_C2(a);
a=0x3D;
TRANSMIT_C2(a);


a=0x00;         ///////////// color
TRANSMIT_C2(a);
a=0x00;
TRANSMIT_C2(a);
__delay32(1000); 
a=0x72;              ////////////////////////// DISPLAY WINDOW ////////////////////////////////////
TRANSMIT_C2(a);

a=0x00;             ///////////////////////// HORIZONTAL START //////////////////////////////////
TRANSMIT_C2(a);
a=0x18;
TRANSMIT_C2(a);
a=0x00;             ///////////////////////// VERTICAL START //////////////////////////////////
TRANSMIT_C2(a);
a=0x30;
TRANSMIT_C2(a);

a=0x00;            ///////////////////////// HORIZONTAL END //////////////////////////////////
TRANSMIT_C2(a);
a=0x54;
TRANSMIT_C2(a);
a=0x00;            ///////////////////////// VERTICAL END //////////////////////////////////
TRANSMIT_C2(a);
a=0x3D;
TRANSMIT_C2(a);


a=0xFF;         ///////////// color
TRANSMIT_C2(a);
a=0xFF;
TRANSMIT_C2(a);
__delay32(10000); 
}



void display_black2()

{

a=0x72;              ////////////////////////// DISPLAY WINDOW ////////////////////////////////////
TRANSMIT_C2(a);

a=0x00;             ///////////////////////// HORIZONTAL START //////////////////////////////////
TRANSMIT_C2(a);
a=0x18;
TRANSMIT_C2(a);
a=0x00;             ///////////////////////// VERTICAL START //////////////////////////////////
TRANSMIT_C2(a);
a=0x40;
TRANSMIT_C2(a);

a=0x00;            ///////////////////////// HORIZONTAL END //////////////////////////////////
TRANSMIT_C2(a);
a=0x54;
TRANSMIT_C2(a);
a=0x00;            ///////////////////////// VERTICAL END //////////////////////////////////
TRANSMIT_C2(a);
a=0x4D;
TRANSMIT_C2(a);


a=0x00;         ///////////// color
TRANSMIT_C2(a);
a=0x00;
TRANSMIT_C2(a);
__delay32(1000); 
a=0x72;              ////////////////////////// DISPLAY WINDOW ////////////////////////////////////
TRANSMIT_C2(a);

a=0x00;             ///////////////////////// HORIZONTAL START //////////////////////////////////
TRANSMIT_C2(a);
a=0x18;
TRANSMIT_C2(a);
a=0x00;             ///////////////////////// VERTICAL START //////////////////////////////////
TRANSMIT_C2(a);
a=0x40;
TRANSMIT_C2(a);

a=0x00;            ///////////////////////// HORIZONTAL END //////////////////////////////////
TRANSMIT_C2(a);
a=0x54;
TRANSMIT_C2(a);
a=0x00;            ///////////////////////// VERTICAL END //////////////////////////////////
TRANSMIT_C2(a);
a=0x4D;
TRANSMIT_C2(a);


a=0xFF;         ///////////// color
TRANSMIT_C2(a);
a=0xFF;
TRANSMIT_C2(a);

}


