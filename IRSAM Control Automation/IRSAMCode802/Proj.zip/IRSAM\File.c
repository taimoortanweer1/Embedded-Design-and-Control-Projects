	#include <p33FJ64MC802.h>
	#include <libpic30.h>
    #include <stdio.h>
    #include <stdlib.h>
    #include <string.h>
	
    //#define XTFREQ          7370000         //FRC frequency 
	#define FCY             39613000        //Instruction Cycle Frequency
	
	#define BAUDRATE         9600		      
	#define BRGVAL          ((FCY/BAUDRATE)/16)-1
	#define BAUDRATE2         19200	      
	#define BRGVAL2          ((FCY/BAUDRATE2)/16)-1  

    
	
	
	
	//*****************SABERTOOTH DRIVE FUNCTIONS****************
	//SUPPOSING SABERTOOTH IS CONNECTING WITH UART 1: RP8
    void clk(void);
    void configuration();
    void INIT_UART2( void );
    void INIT_UART1( void );
    unsigned char GET_C2(void);
    void TRANSMIT_C2(unsigned char value);
    unsigned char GET_C1(void);

    void Main_Func();
    void timmer(unsigned int value);
    void timmer1(unsigned int value);
    void func_PI(unsigned int value);
 

    void INIT_SABERTOOTH();
    void INIT_UART_START(void);
    void TRANSMIT_C1(unsigned char value);
    void FORWARD1(char address, char speed);
    void FORWARD2(char address, char speed);
    void BACKWARD1(char address, char speed);
    void BACKWARD2(char address, char speed);
    void INIT_UART_LCD( void );
    void funcn_PI(unsigned int value);
    void func_all(unsigned int value);

    unsigned int read=0,read1=0,a=0,readx=0,ready=0,readx1=0,ready1=0;
    unsigned int timePeriod1=0,flag=0,ref2=0,flag2=0;
    char arr;
	unsigned int r=0,j=0;
    char data[10];
   
    

void __attribute__((__interrupt__, no_auto_psv)) _U2RXInterrupt(void)
{

   
	read = GET_C2();
	r++;
  

}

void __attribute__((__interrupt__, no_auto_psv)) _U1RXInterrupt(void)
{

   
	arr = GET_C1();

}

////////////////////////////////////////////////////////////////// IC1 ///////////////////////////////////////

void __attribute__((__interrupt__, no_auto_psv)) _IC1Interrupt(void)
	{
	unsigned int t1;
	t1=0;
	if(T1CONbits.TON==0)
	{
		TMR1=0x00;
		T1CONbits.TON=1;
	}
	else
	{
		T1CONbits.TON=0;
		timePeriod1=TMR1;
        
	
	}
	a=a+1;
	_IC1IF = 0;
	
	return;
    }
	
	
int main(void)
{

unsigned int i;
char str[10];
 clk();
 configuration();

 while(1)
   {
   TRANSMIT_C1('u');  
       
   }             
             while(1)
               {     
                          
                         if(data[j-1]=='E')
                                break;
               }

             for(i=0;i<5;i++)
			   {
				str[i]=data[i];
               } 
                 
         
                  ref2=atoi(str);
func_all(200);

   Main_Func();

TRANSMIT_C2('U');
__delay32(10000000);


while(1);










/*
button1();
__delay32(10000000);
enable_touch();
__delay32(10000000);
while(1)
{

__delay32(5000000);
back();


}
*/
/*

while(arr==0);


while(1)
{

for(i=0;i<5;i++)
{

str[i]=arr;
//i=i+1;
arr=0;
while(arr==0);

}

__delay32(1500000);
a=0x73;
TRANSMIT_C2(a);
a=0x00;
TRANSMIT_C2(a);
a=0x00;
TRANSMIT_C2(a);
a=0x03;
TRANSMIT_C2(a);
a=0xff;
TRANSMIT_C2(a);
TRANSMIT_C2(a);

for(s=0;s<5;s++)
{
TRANSMIT_C2(str[s]);
}

a=0x00;
TRANSMIT_C2(a);



arr=0;
while(arr==0);
__delay32(1500000);
TRANSMIT_C2('E');
i=0;

}

*/








return(0);

}


///////////////////////////////////////////////////////////////////// CLOCK ///////////////////////////////////////////////////////////////////
	void clk(void)
	{
	
	// Configure Oscillator to operate the device at 40Mhz
	// Fosc= Fin*M/(N1*N2), Fcy=Fosc/2
	// Fosc= 7.37*43/(2*2)=79.23MHz
		PLLFBD=41;					// M=43
		CLKDIVbits.PLLPOST=0;		// N1=2
		CLKDIVbits.PLLPRE=0;		// N2=2
	
	// Disable Watch Dog Timer
		RCONbits.SWDTEN=0;
	
	// Wait for PLL to lock
		while(OSCCONbits.LOCK!=1) {};
	}

/////////////////////////////////////////////////////////////// CONFIGURATION //////////////////////////////////////////////////////////////

 void configuration()
{
//INIT_UART2();
  __delay32(40000000);
  __delay32(20000000);
//INIT_UART_LCD();
//INIT_UART_START();
//INIT_SABERTOOTH();
INIT_UART1();

}

///////////////////////////////////////////////////////////// INITIALIZING UART 1 ////////////////////////////////////////////////////////
/*	void INIT_UART1()                 /////////////// serial 2 controller 3 ///////////////
{	
	RPINR18 = 7;	// = 9 acceptable		
	RPOR3bits.RP6R = 3;	
		
	TRISBbits.TRISB7 = 1; //7
	TRISBbits.TRISB6=  0; //6
	
	U1BRG  = BRGVAL;

	_U1RXIP = 7;	
	_U1RXIF = 0;
    _U1RXIE = 1;

	U1MODE = 0x8000; 	
	U1STA  = 0x0440; 
		
}
*/
/*	void INIT_UART1()                     //////////// serial 1 controller 1 /////////////////  //////////// serial 2 controller 2 ////////////////////
{	
	RPINR18 = 4;	// = 9 acceptable		
	RPOR2bits.RP5R = 3;	
		
	TRISBbits.TRISB4 = 1; //7
	TRISBbits.TRISB5=  0; //6
	
	U1BRG  = BRGVAL;

	_U1RXIP = 7;	
	_U1RXIF = 0;
    _U1RXIE = 1;

	U1MODE = 0x8000; 	
	U1STA  = 0x0440; 
		
}
*/
/*	void INIT_UART1()           ///////////////////// serial 1 controller 2 //////////////////////
{	
	RPINR18 = 12;	// = 9 acceptable		
	RPOR5bits.RP11R = 3;	
		
	TRISBbits.TRISB12 = 1; //7
	TRISBbits.TRISB11=  0; //6
	
	U1BRG  = BRGVAL;

	_U1RXIP = 7;	
	_U1RXIF = 0;
    _U1RXIE = 1;

	U1MODE = 0x8000; 	
	U1STA  = 0x0440; 
		
}*/

void INIT_UART1()           ///////////////////// serial 1 controller 3 //////////////////////
{	
	RPINR18 = 5;	// = 9 acceptable		
	RPOR2bits.RP4R = 3;	
		
	TRISBbits.TRISB12 = 1; //7
	TRISBbits.TRISB5=  0; //6
	
	U1BRG  = BRGVAL;

	_U1RXIP = 7;	
	_U1RXIF = 0;
    _U1RXIE = 1;

	U1MODE = 0x8000; 	
	U1STA  = 0x0440; 
		
}


///////////////////////////////////////////////////////// TRANSMIT FUNCTION FOR UART 1 //////////////////////////////////////////

void TRANSMIT_C1(unsigned char value)
{
	while(!U1STAbits.TRMT);
	U1TXREG = value;
	while(!U1STAbits.TRMT);
	_U1RXIF=0;				//Clear UART RX Interrupt Flag
}

////////////////////////////////////////////////////// INTIALIZING UART 2 /////////////////////////////////////////////////

	void INIT_UART2( void )
{	
     RPINR19 = 5;	// = 9 acceptable		
	 RPOR2bits.RP4R = 5;	
		
	//TRISBbits.TRISB7 = 0;
	TRISBbits.TRISB5 = 1;
	
	U2BRG  = BRGVAL;

	IPC7bits.U2RXIP = 7;	
	IFS1bits.U2RXIF = 0;
	IEC1bits.U2RXIE = 1;

	U2MODE = 0x8000; 	
	U2STA  = 0x0440; 
		
}

////////////////////////////////////////////////////// TRANSMIT FUNCTION FOR UART 2 /////////////////////////////////////////////////

void TRANSMIT_C2(unsigned char value)
{
	while(!U2STAbits.TRMT);
	U2TXREG = value;
	while(!U2STAbits.TRMT);
	_U2RXIF=0;				//Clear UART RX Interrupt Flag
}

///////////////////////////////////////////////////// RECEIVE FUNCTION FOR UART 1 ///////////////////////////////////////////////////

unsigned char GET_C1(void)
{
	while (_U1RXIF==0);			// Wait and Receive One Character
	_U1RXIF = 0;
	return U1RXREG;
}


//////////////////////////////////////////////////// RECEIVE FUNCTION FOR UART 2 /////////////////////////////////////////////////////////

unsigned char GET_C2(void)
{
	while (IFS1bits.U2RXIF==0);			// Wait and Receive One Character
	IFS1bits.U2RXIF = 0;
    data[j]=U2RXREG;
    j++;
	return U2RXREG;
}

////////////////////////////////////////////////// INITIALIZING CAPTURE /////////////////////////////////////////////////////////////

void capture()
{

   	RPINR7bits.IC1R = 8;

    IC1CONbits.ICM=0b00; 				// Disable Input Capture 1 module                left
	IC1CONbits.ICTMR= 1; 				// Select Timer2 as the IC1 Time base
	IC1CONbits.ICI= 0b00; 				// Interrupt on every  capture event
	IC1CONbits.ICM= 0b011;


    T1CON=0X00;

    TRISBbits.TRISB8=1;

    IPC0bits.IC1IP = 1; // Setup IC1 interrupt priority level
	IFS0bits.IC1IF = 0; // Clear IC1 Interrupt Status Flag
	IEC0bits.IC1IE = 0; // Enable IC1 interrupt

}



///////////////////////////////////////////////////////// INITIALIZING UART FOR SABER TOOTH ////////////////////////////////////////// 

	void INIT_UART_START()
	{
	
	//	RPINR19 = 10;			// Make Pin RP9 U1RX
		RPOR5bits.RP10R = 3;		// Make Pin RP8 U1TX
		
	//	TRISBbits.TRISB9 = 1;
		TRISBbits.TRISB10 = 0;
	
	//	AD1PCFGL = 0x03C0;		// Make analog pins digital 
		U1BRG  = BRGVAL;

		U1MODE = 0x8000; /* Reset UART to 8-n-1, alt pins, and enable */
		U1STA  = 0x0440; /* Reset status register and enable TX & RX*/
	
	
	}

	void INIT_UART_LCD( void )
{	
    RPINR18 = 12;	// 18 for serail 1 & 19 for serial 2	
	RPOR6bits.RP13R = 3;	// 3 for serial 1 & 5 for serial 2
		
	TRISBbits.TRISB13 = 0;
	TRISBbits.TRISB12 = 1;
	
	U1BRG  = BRGVAL;

	_U1RXIP = 7;	
	_U1RXIF = 0;
    _U1RXIE = 1;

	U1MODE = 0x8000; 	
	U1STA  = 0x0440; 
		
}




/////////////////////////////////////////////////// INITIALIZING SABERTOOTH ////////////////////////////////////////////////////////////////

 void INIT_SABERTOOTH(void)
	{
	
	TRANSMIT_C1(0xAA); //Autobauding character to Sabertooth
	__delay32(2000000); //100mSEC delay
	
	}

//////////////////////////////////////////////// FORWARD 1 //////////////////////////////////////////

	void FORWARD1(char address, char speed)
	{
	TRANSMIT_C1(address);
	TRANSMIT_C1(0); //drive motor 1 forward command
	TRANSMIT_C1(speed);
	TRANSMIT_C1((address + 0 + speed) & 0b01111111);
	}

//////////////////////////////////////////////// FORWARD 2 //////////////////////////////////////////
	
	void FORWARD2(char address, char speed)
	{
	TRANSMIT_C1(address);
	TRANSMIT_C1(4); //drive motor 2 forward command
	TRANSMIT_C1(speed);
	TRANSMIT_C1((address + 4 + speed) & 0b01111111);
	}

//////////////////////////////////////////////// BACKWARD 1 //////////////////////////////////////////
	
	void BACKWARD1(char address, char speed)
	{
	TRANSMIT_C1(address);
	TRANSMIT_C1(1); //drive motor 1 backwards command
	TRANSMIT_C1(speed);
	TRANSMIT_C1((address + 1 + speed) & 0b01111111);
	}

//////////////////////////////////////////////// BACKWARD 2 //////////////////////////////////////////
	
	void BACKWARD2(char address, char speed)
	{
	TRANSMIT_C1(address);
	TRANSMIT_C1(5);//drive motor 2 backwards command
	TRANSMIT_C1(speed);
	TRANSMIT_C1((address + 5 + speed) & 0b01111111);
	}




void funcn(unsigned int val)
{
             RPINR16bits.QEA2R=15;            /////////////// Map pins for Encoder //////////////
		    RPINR16bits.QEB2R=14;
		
		    TRISBbits.TRISB14=1;             ////////////// Setting pins as input ///////////////
		    TRISBbits.TRISB15=1;



        MAX2CNT=35000;  ///5800
     	POS2CNT=100;
       IFS3bits.QEI1IF=0;
        QEI2CON= 0X0000;

        QEI2CONbits.PCDOUT=1;
        QEI2CONbits.SWPAB=0;
      
    
        
      	QEI2CONbits.QEIM=7;
         
        while(POS2CNT<val);
     

           QEI2CONbits.QEIM=0;
           IFS4bits.QEI2IF=0;
        


}

void func(unsigned int val)
{
             RPINR16bits.QEA2R=15;            /////////////// Map pins for Encoder //////////////
		    RPINR16bits.QEB2R=14;
		
		    TRISBbits.TRISB14=1;             ////////////// Setting pins as input ///////////////
		    TRISBbits.TRISB15=1;



        MAX2CNT=35000;  ///5800
     	POS2CNT=100;
       IFS3bits.QEI1IF=0;
        QEI2CON= 0X0000;

        QEI2CONbits.PCDOUT=1;
        QEI2CONbits.SWPAB=1;
        
    
        
      	QEI2CONbits.QEIM=7;
         
        while(POS2CNT<val);
     

           QEI2CONbits.QEIM=0;
           IFS4bits.QEI2IF=0;
        


}
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////





void Main_Func()
{

    unsigned int i,count=0,flag2=3,y,s;
    float ref=0,angle=0,diff=0;
    
   char str[20]; 

  TRANSMIT_C2('S');  
       
                
             while(1)
               {     
                          
                         if(data[j-1]=='E')
                                break;
               }

             for(i=0;i<5;i++)
			   {
				str[i]=data[i];
               } 
                 
         
                  ref=atoi(str);
                
    while(1)
             { 
            
          
 	             diff=0; 
                 count=0;
                 j=0;
   
                    TRANSMIT_C2('S');  
       
          
             while(1)
               {     
                          
                         if(data[j-1]=='E')
                                break;
               }

             for(i=0;i<5;i++)
			    {
				str[i]=data[i];
                } 
                 
         
                  angle=atoi(str);

                  diff=angle-ref;
                  
                      

                 if(diff<-150)                     //////// CASE FOR ANGLE GOING FROM 360 TO 0
                       {
                               diff=diff+360;
                               flag2=1;

                       }
                  else if(diff>150)               ///////// CASE OF ANGLE GOING FROM 0 TO 360
                       {
                               diff=360-diff;
                               flag2=0;

                       }

                  else if(diff<0 && diff>-50)    ///////// CASE OF ANGLE SMALLER THEN REFRENCE
                       {
                               diff=-1*diff;
                               flag2=0;
                       }
                  else                          /////////// CASE OF ANGLE GREATER THEN REFRENCE
                       {
                                  flag2=1;
                       }
            
                   j=0;

                 if(diff>6 && flag2==1)
                        {
                                     
                                      ref=angle;
                                      count=22*diff;
                                      count=count+200;
                                      funcn_PI(count);
                                          
                        }
                    
                  else if(diff>6 && flag2==0)
                        {
                                      
                                      ref=angle;
                                      count=22*diff;
                                      count=count+200;
                                      func_PI(count);
                                   
                        }

                  else 
                       {

                          FORWARD1(128,0);
                       }

                 flag2=3;
               
                    /*

     if(diff>1)
          {       
             
  TRANSMIT_C1('E');

  y = sprintf(str, "%f",diff);
  s=strlen(str); 
  __delay32(1500000);
  a=0x73;
  TRANSMIT_C1(a);
  a=0x00;
  TRANSMIT_C1(a);
  a=0x00;
  TRANSMIT_C1(a);
  a=0x03;
  TRANSMIT_C1(a);
  a=0xff;
  TRANSMIT_C1(a);
  TRANSMIT_C1(a);

  for(s=0;s<5;s++)
   {
   TRANSMIT_C1(str[s]);
   }

  a=0x00;
  TRANSMIT_C1(a);

          } 
                       
                    
                 
         */     
                  

       }   
              


}

void timmer1(unsigned int value)
{


T1CON=32;
//_T1IE=1;
_T1IF=0;
//_T1IP=1;
TMR1=value;
T1CONbits.TON=1;
}



void timmer(unsigned int value)
{


T1CON=32;
//_T1IE=1;
_T1IF=0;
//_T1IP=1;
TMR1=value;
//T1CONbits.TON=1;


            QEI2CONbits.QEIM=0;              //////////////// Shutdown encoder //////////////////
		    IFS4bits.QEI2IF=0;               /////////////// Reset Intrrupt Flag ////////////////

		    RPINR16bits.QEA2R=15;            /////////////// Map pins for Encoder //////////////
		    RPINR16bits.QEB2R=14;
		
		    TRISBbits.TRISB14=1;             ////////////// Setting pins as input ///////////////
		    TRISBbits.TRISB15=1;



	        MAX2CNT=35000;  ///5800          /////////// Max value to be compared to /////////////////
	        POS2CNT=0;                     ////////// Intial value for Position count //////////////
	        IFS3bits.QEI1IF=0;               /////////////// Reset Intrrupt Flag /////////////////////
	        QEI2CON= 0X0000;                 ////////////// Initialize Control Register //////////////    
	
	        QEI2CONbits.PCDOUT=1;
              if(flag==0)
                 {
	             QEI2CONbits.SWPAB=0;             ///////////////// Set Direction ////////////////////////
	             }
              if(flag==1)
                 {
	             QEI2CONbits.SWPAB=1;             ///////////////// Set Direction ////////////////////////
	             }
     
         //  FORWARD1(128 , 20);
        	QEI2CONbits.QEIM=7;              ///////////////// Start Encoder ///////////////////////
             T1CONbits.TON=1;



}




//////////////////////////////////////////// Position Control //////////////////////////////////////



void func_PI(unsigned int value)
{
	 int err = 0,  P_Term = 0,I_State=0 ,val=0;
	 float kp=2;
     float ki= .0098, I_Term=0 ;
     
    

		    QEI2CONbits.QEIM=0;              //////////////// Shutdown encoder //////////////////
		    IFS4bits.QEI2IF=0;               /////////////// Reset Intrrupt Flag ////////////////

		    RPINR16bits.QEA2R=15;            /////////////// Map pins for Encoder //////////////
		    RPINR16bits.QEB2R=14;
		
		    TRISBbits.TRISB14=1;             ////////////// Setting pins as input ///////////////
		    TRISBbits.TRISB15=1;



	        MAX2CNT=35000;  ///5800          /////////// Max value to be compared to /////////////////
	        POS2CNT=200;                     ////////// Intial value for Position count //////////////
	        IFS3bits.QEI1IF=0;               /////////////// Reset Intrrupt Flag /////////////////////
	        QEI2CON= 0X0000;                 ////////////// Initialize Control Register //////////////    
	
	        QEI2CONbits.PCDOUT=1;
	        QEI2CONbits.SWPAB=1;             ///////////////// Set Direction ////////////////////////
	   
     
        
        	QEI2CONbits.QEIM=7;              ///////////////// Start Encoder ///////////////////////
    
  
while(1)
{

   
	err    = (value) - POS2CNT;   // Error term obtained by subtracting feedback from desired value
	P_Term = err * kp;           //  Proportional gain

    I_State= I_State + err;     //   Accumalted Error

    if (I_State >=1100)
	I_State=1100;
    if (I_State <=-1100)
	I_State=-1100;

    I_Term = I_State * ki;     //    Integral gain


    val   = P_Term + I_Term;            /////////////////////////////// Value for PWM //////////////////////////////

            if(val<10 && val>-10)
              break;
          

    if(val > 125)
	  {

	    FORWARD1(128, 125);       /////////////////////////////// Move Forward /////////////////////////////////

	  }
	
  else if(val<=125)
      {
        
        FORWARD1(128, val);      ////////////////////////////// Move Forwrd /////////////////////////////////

      } 	


	 else if(val < 0)
	  {
		       val = -1 * val;
             
              if(val > 125)
	                {
                     BACKWARD1(128, 125);            /////////////////////////////////////// Move Backwards /////////////////////////////////
                    }

              else if(val<=125)
                    {
                      BACKWARD1(128, val);          ////////////////////////////////////// Move Backwards /////////////////////////////////
                    } 
		
	   }

    
	

  
   
}
   
       QEI2CONbits.QEIM=0;
       IFS4bits.QEI2IF=0;



}



//////////////////////////////////////////// Position Control //////////////////////////////////////



void funcn_PI(unsigned int value)
{
	 int err = 0,  P_Term = 0,I_State=0 ,val=0;
	 float kp=2;
     float ki= .0095, I_Term=0 ;
     //char str[10];
    

		    QEI2CONbits.QEIM=0;              //////////////// Shutdown encoder //////////////////
		    IFS4bits.QEI2IF=0;               /////////////// Reset Intrrupt Flag ////////////////

		    RPINR16bits.QEA2R=15;            /////////////// Map pins for Encoder //////////////
		    RPINR16bits.QEB2R=14;
		
		    TRISBbits.TRISB14=1;             ////////////// Setting pins as input ///////////////
		    TRISBbits.TRISB15=1;



	        MAX2CNT=35000;  ///5800          /////////// Max value to be compared to /////////////////
	        POS2CNT=200;                     ////////// Intial value for Position count //////////////
	        IFS3bits.QEI1IF=0;               /////////////// Reset Intrrupt Flag /////////////////////
	        QEI2CON= 0X0000;                 ////////////// Initialize Control Register //////////////    
	
	        QEI2CONbits.PCDOUT=1;
	        QEI2CONbits.SWPAB=0;             ///////////////// Set Direction ////////////////////////
	   
     
        
        	QEI2CONbits.QEIM=7;              ///////////////// Start Encoder ///////////////////////
    
  
while(1)
{

   
	err    = (value) - POS2CNT;   // Error term obtained by subtracting feedback from desired value
	P_Term = err * kp;           //  Proportional gain

         I_State= I_State + err;     //   Accumalted Error
    if (I_State >=1100)
	I_State=1100;
    if (I_State <=-1100)
	I_State=-1100;
       I_Term = I_State * ki;     //    Integral gain


    val   = P_Term + I_Term;            /////////////////////////////// Value for PWM //////////////////////////////

            if(val<15 && val>-15)
              break;
          

    if(val > 125)
	  {

	    BACKWARD1(128, 125);       /////////////////////////////// Move Forward /////////////////////////////////

	  }
	
   else if(val<=125)
      {
        
        BACKWARD1(128, val);      ////////////////////////////// Move Forwrd /////////////////////////////////

      } 	


	else if(val < 0)
	  {
		       val = -1 * val;
             
              if(val > 125)
	                {
                     FORWARD1(128, 125);            /////////////////////////////////////// Move Backwards /////////////////////////////////
                    }

              else if(val<=125)
                    {
                      FORWARD1(128, val);          ////////////////////////////////////// Move Backwards /////////////////////////////////
                    } 
		
	   }

    
	

  
   
}
   
       QEI2CONbits.QEIM=0;
       IFS4bits.QEI2IF=0;



}




void func_all(unsigned int value)
{
	 int err = 0,  P_Term = 0,I_State=0 ,val=0,check;
	 float kp=.6;
     float ki= .0007, I_Term=0 ;
      float ref=0,angle=0,diff=0,count=0;
      char str[20]; 
      unsigned int i,flag3=0;
     
    

		    QEI2CONbits.QEIM=0;              //////////////// Shutdown encoder //////////////////
		    IFS4bits.QEI2IF=0;               /////////////// Reset Intrrupt Flag ////////////////

		    RPINR16bits.QEA2R=15;            /////////////// Map pins for Encoder //////////////
		    RPINR16bits.QEB2R=14;
		
		    TRISBbits.TRISB14=1;             ////////////// Setting pins as input ///////////////
		    TRISBbits.TRISB15=1;



	        MAX2CNT=35000;  ///5800          /////////// Max value to be compared to /////////////////
	        POS2CNT=200;                     ////////// Intial value for Position count //////////////
	        IFS3bits.QEI1IF=0;               /////////////// Reset Intrrupt Flag /////////////////////
	        QEI2CON= 0X0000;                 ////////////// Initialize Control Register //////////////    
	
	        QEI2CONbits.PCDOUT=1;
	        QEI2CONbits.SWPAB=1;             ///////////////// Set Direction ////////////////////////
	   
     
        
        	QEI2CONbits.QEIM=7;              ///////////////// Start Encoder ///////////////////////

                 ref=ref2;
    
  
while(1)
{

   
	err    = (value) - POS2CNT;   // Error term obtained by subtracting feedback from desired value
	P_Term = err * kp;           //  Proportional gain

    I_State= I_State + err;     //   Accumalted Error

    if (I_State >=1500)
	I_State=1500;
    if (I_State <=-1500)
	I_State=-1500;

    I_Term = I_State * ki;     //    Integral gain


    val   = P_Term + I_Term;            /////////////////////////////// Value for PWM //////////////////////////////

            //if(val<10 && val>-10)
              //break;


   if(val > 115)
	  {

	    FORWARD1(128, 115);       /////////////////////////////// Move Forward /////////////////////////////////
        BACKWARD2(128,115);
	  }
	
  else if(val<=115)
      {
        
        FORWARD1(128, val);      ////////////////////////////// Move Forwrd /////////////////////////////////
        BACKWARD2(128,val);
      } 	


	 else if(val < 0)
	  {
		       val = -1 * val;
             
              if(val > 115)
	                {
                     BACKWARD1(128, 115);            /////////////////////////////////////// Move Backwards /////////////////////////////////
                     FORWARD2(128,115);
                    }

              else if(val<=115)
                    {
                      BACKWARD1(128, val);          ////////////////////////////////////// Move Backwards /////////////////////////////////
                      FORWARD2(128,val);
                    } 
		
	   }




   ///////////////////////////////////////////////////////////////////////// Angle Check /////////////////////////////////////////////////////////////////// 
	                  
   
                    TRANSMIT_C2('S');  
       
         
                
                          
                  if(data[j-1]=='E')
                                
                      {      
                     
             for(i=0;i<5;i++)
			    {
				str[i]=data[i];
                } 
                 
         
                  angle=atoi(str);

                  diff=angle-ref;
                  
                      

                 if(diff<-150)                     //////// CASE FOR ANGLE GOING FROM 360 TO 0
                       {
                               diff=diff+360;
                               flag2=1;

                       }
                  else if(diff>150)               ///////// CASE OF ANGLE GOING FROM 0 TO 360
                       {
                               diff=360-diff;
                               flag2=0;

                       }

                  else if(diff>0 && diff<60)    ///////// CASE OF ANGLE SMALLER THEN REFRENCE
                       {
                              // diff=-1*diff;
                               flag2=1;
                       }
                  else                          /////////// CASE OF ANGLE GREATER THEN REFRENCE
                       {
                                 diff=-1*diff;
                                  flag2=0;
                       }

               
                    
                        
                                  check=value-POS2CNT;
                                  count=diff*22;
                                  value=count+200+check;
                                  POS2CNT=200;
                                  ref=angle;
                                  I_State=0;

                                 if(flag2==1)
                                    {
                                  count=diff*22;
                                  value=count+200;  
                                  ref2=angle;  
                                  I_State=0;    
                                  j=0;
                                  funcn_all(value);
                              
                                    }

                                 
                              
                      
                  
              j=0;
               
                  }
             
   
}
   
       QEI2CONbits.QEIM=0;
       IFS4bits.QEI2IF=0;



}





void funcn_all(unsigned int value)
{
	 int err = 0,  P_Term = 0,I_State=0 ,val=0,check;
	 float kp=.5;
     float ki= .0007, I_Term=0 ;
      float ref=0,angle=0,diff=0,count=0;
      char str[20]; 
      unsigned int i,flag3=0;
     
    

		    QEI2CONbits.QEIM=0;              //////////////// Shutdown encoder //////////////////
		    IFS4bits.QEI2IF=0;               /////////////// Reset Intrrupt Flag ////////////////

		    RPINR16bits.QEA2R=15;            /////////////// Map pins for Encoder //////////////
		    RPINR16bits.QEB2R=14;
		
		    TRISBbits.TRISB14=1;             ////////////// Setting pins as input ///////////////
		    TRISBbits.TRISB15=1;



	        MAX2CNT=35000;  ///5800          /////////// Max value to be compared to /////////////////
	        POS2CNT=200;                     ////////// Intial value for Position count //////////////
	        IFS3bits.QEI1IF=0;               /////////////// Reset Intrrupt Flag /////////////////////
	        QEI2CON= 0X0000;                 ////////////// Initialize Control Register //////////////    
	
	        QEI2CONbits.PCDOUT=1;
	        QEI2CONbits.SWPAB=0;             ///////////////// Set Direction ////////////////////////
	   
     
        
        	QEI2CONbits.QEIM=7;              ///////////////// Start Encoder ///////////////////////
                 ref=ref2;
    
  
while(1)
{

   
	err    = (value) - POS2CNT;   // Error term obtained by subtracting feedback from desired value
	P_Term = err * kp;           //  Proportional gain

    I_State= I_State + err;     //   Accumalted Error

    if (I_State >=1500)
	I_State=1500;
    if (I_State <=-1500)
	I_State=-1500;

    I_Term = I_State * ki;     //    Integral gain


    val   = P_Term + I_Term;            /////////////////////////////// Value for PWM //////////////////////////////

            //if(val<10 && val>-10)
              //break;


   if(val > 115)
	  {

	    FORWARD2(128, 115);       /////////////////////////////// Move Forward /////////////////////////////////
        BACKWARD1(128,115);
	  }
	
  else if(val<=115)
      {
        
        FORWARD2(128, val);      ////////////////////////////// Move Forwrd /////////////////////////////////
        BACKWARD1(128,val);
      } 	


	 else if(val < 0)
	  {
		       val = -1 * val;
             
              if(val > 115)
	                {
                     BACKWARD2(128, 115);            /////////////////////////////////////// Move Backwards /////////////////////////////////
                     FORWARD1(128,115);
                    }

              else if(val<=115)
                    {
                      BACKWARD2(128, val);          ////////////////////////////////////// Move Backwards /////////////////////////////////
                      FORWARD1(128,val);
                    } 
		
	   }




   ///////////////////////////////////////////////////////////////////////// Angle Check /////////////////////////////////////////////////////////////////// 
	                  
   
                    TRANSMIT_C2('S');  
       
         
                
                          
                  if(data[j-1]=='E')
                                
                      {      
                     
                      for(i=0;i<5;i++)
			               {
				          str[i]=data[i];
                           } 
                 
         
                        angle=atoi(str);

                        diff=angle-ref;
                  
                      

                 if(diff<-150)                     //////// CASE FOR ANGLE GOING FROM 360 TO 0
                       {
                               diff=diff+360;
                               flag2=1;

                       }

                  else if(diff>150)               ///////// CASE OF ANGLE GOING FROM 0 TO 360
                       {
                               diff=360-diff;
                               flag2=0;

                       }

                  else if(diff<0 && diff>-90)    ///////// CASE OF ANGLE SMALLER THEN REFRENCE
                       {
                               diff=-1*diff;
                               flag2=0;
                       }
                  else                          /////////// CASE OF ANGLE GREATER THEN REFRENCE
                       {
                               // diff=-1*diff;
                                  flag2=1;
                       }

                               
                               
                                          
                                  check=value-POS2CNT;
                                  count=diff*22;
                                  value=count+200+check;
                                  POS2CNT=200;
                                  ref=angle;
                                  I_State=0;
                                   
                                if(flag2==0)
                                 {
                                  count=diff*22;
                                  value=count+200;  
                                  ref2=angle;      
                                  I_State=0;
                                   j=0;
                                  func_all(value);
                              
                                  }
                  
                          j=0;
               
                  }
             
   
}
   
       QEI2CONbits.QEIM=0;
       IFS4bits.QEI2IF=0;



}
